# BÀI 3. KHI AI LÀM SAI: BÁO CÁO

Các thử nghiệm làm trên **bản sao** (`public-thu-nghiem`, `public-ban-sao-2`, `public-hong`), đã xoá khỏi thư mục nộp. Số liệu dưới đây đo bằng Chrome không giao diện, tương đương việc xem trong DevTools.

## 3.1. Tái hiện lỗi và báo lỗi bằng dữ kiện

- Sửa dòng `<link>` trong `index.html` thành `href="css/styles.css"` (thêm chữ **s**).
- Kết quả: trang mất định dạng, nền đầu trang trở về trong suốt `rgba(0, 0, 0, 0)` thay vì kem trắng `rgb(255, 251, 244)`.
- Tab Console: dòng đỏ `Failed to load resource: net::ERR_FILE_NOT_FOUND`.
- Tab Network: dòng `styles.css` đỏ, lỗi `ERR_FILE_NOT_FOUND`. (Các dòng đỏ của ảnh `placehold.co` chỉ do máy thử không có Internet, bỏ qua.)
- Tự sửa lại thành `css/style.css`: nền đầu trang trở lại `rgb(255, 251, 244)`.

Báo lỗi theo mẫu, điền sẵn:

```
Trang chủ bị mất định dạng.
- Đã làm: sửa dòng <link> trong index.html rồi mở bằng Chrome
- Mong đợi: giao diện nâu kem như trước
- Thực tế: chữ đen trên nền trắng, không có màu
- Tab Console: Failed to load resource: net::ERR_FILE_NOT_FOUND
- Ảnh chụp tab Network: [đính kèm, dòng styles.css màu đỏ]
- Nội dung file index.html: [dán nội dung]
Hãy giải thích NGUYÊN NHÂN trước, rồi mới hướng dẫn cách sửa.
```

Bài học: có dữ kiện (tên file, mã lỗi) thì AI chỉ ra đúng chỗ sai mà không cần viết lại cả trang.

## 3.2. Đòi file đầy đủ

Thêm nút "Lên đầu trang" ở góc dưới bên phải. Việc này phải sửa **2 file, 2 chỗ**:

- `public/css/style.css`: thêm khối `.nut-len-dau-trang` (dùng `position: fixed; right: 20px; bottom: 20px;`) vào cuối file.
- `public/index.html`: thêm `<a class="nut-len-dau-trang" href="#">Lên đầu trang</a>` ngay trước `</body>`.

Kiểm tra: nút cách mép phải và mép dưới đúng 20px; cuộn xuống cuối trang (scrollY = 1301) rồi bấm nút thì về đầu trang (scrollY = 0).

Nếu chỉ nhận đoạn code rời, người mới khó biết dán vào file nào, ở dòng nào, và dễ dán vào giữa một quy tắc khác làm hỏng CSS. Gửi lại toàn bộ file thì chỉ cần chọn tất cả và dán đè (Ctrl + A, Ctrl + V). Đây là lý do của nguyên tắc số 4: đòi file đầy đủ.

## 3.3. Hỏi "tại sao" và kiểm chứng

Thử tắt từng dòng như tắt dấu tích trong DevTools:

| Dòng CSS | AI nói | Kết quả đo được |
| --- | --- | --- |
| `display: grid;` (lưới sản phẩm) | Xếp các thẻ thành lưới nhiều cột | Có dòng này: 4 cột, 4 thẻ nằm cùng một hàng (cùng `top = 459px`). Tắt đi: các thẻ chồng dọc, `top` lần lượt 459, 1383, 2306, 3229 |
| `gap: 24px;` | Tạo khoảng cách giữa các ô | Có dòng này: khe giữa thẻ 1 và thẻ 2 là 24px. Tắt đi: 0px, các thẻ dính sát nhau |
| `@media (max-width: 760px)` | Chỉ áp dụng khi màn hình rộng từ 760px trở xuống | Khối giới thiệu có 2 cột ở 1280px và 761px, nhưng chỉ còn 1 cột ở 760px và 375px |

Điểm cần nhớ: mốc 760px là **bằng hoặc nhỏ hơn**, nên đúng 760px đã đổi sang 1 cột.

## 3.5. Mở lại cuộc trò chuyện khi AI "lú"

Đã tạo file `BAI3_MO_LAI_CUOC_TRO_CHUYEN.txt` gồm: khung ngữ cảnh, bản đặc tả, 4 file HTML, file CSS, và câu kết "Đây là trạng thái hiện tại của dự án. Hãy trả lời Đã hiểu và chờ yêu cầu tiếp theo." Dán cả file vào một cuộc trò chuyện mới là AI có đủ bối cảnh để làm tiếp.

## 3.6. Khôi phục từ bản sao

- Sao lưu `public` thành `public-ban-sao-2`.
- Giả lập AI làm hỏng: ghi đè `style.css` bằng nội dung cụt và xoá menu của `dat-banh.html`.
- Đổi tên `public` thành `public-hong`, chép `public-ban-sao-2` thành `public`.
- Kiểm tra: bản hỏng có nền đầu trang trong suốt và 0 mục menu; bản khôi phục có nền `rgb(255, 251, 244)` và 4 mục menu, dấu vân tay (hash) các file trùng khớp bản sao gốc.

## 3.4. Khi AI đổi công nghệ

Chưa làm: bài này cần mở cuộc trò chuyện mới **không dán khung ngữ cảnh** rồi so sánh câu trả lời, nên phải do bạn tự thực hiện với công cụ AI của mình.

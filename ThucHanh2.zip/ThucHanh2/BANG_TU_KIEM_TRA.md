# BẢNG TỰ KIỂM TRA (đã cập nhật)

Họ tên: Liễu Tấn Anh Tuấn | MSSV: 25810138

| # | Tiêu chí | Đạt? | Minh chứng |
| --- | --- | --- | --- |
| 1 | Đã điền bảng so sánh Prompt A và Prompt B ở mục 1.3 | ✓ | `BAI_1/BAI1_BANG_SO_SANH.docx`, đủ 5 hàng và kết luận |
| 2 | Có `DAC_TA.md` đủ 6 mục, nằm trong `du-an-web` (không nằm trong `public`) | ✓ | `BAI_2/du-an-web/DAC_TA.md` |
| 3 | Có `public/index.html` và `public/css/style.css`; tiếng Việt đúng, có màu sắc, bố cục theo đặc tả | ✓ | Đã mở `localhost:3000` trên Chrome, hiển thị đúng |
| 4 | Có ít nhất một trang phụ dùng chung `style.css`, đầu trang, menu, chân trang | ✓ | 3 trang phụ: `san-pham`, `dat-banh`, `gioi-thieu` |
| 5 | Mọi liên kết trong menu, trên mọi trang, đều hoạt động | ✓ | Đã kiểm tra bằng script trên cả 4 trang; nên tự bấm thử một lượt |
| 6 | Trên giả lập điện thoại, bố cục không vỡ, không tràn ngang | ✓ | Đã đo ở 375px; chạy thật trên điện thoại tại `192.168.6.100:3000` (ảnh `BAI2_anh-chup-dien-thoai.jpg`) |
| 7 | Có `NHAT_KY_PROMPT.md` ghi ít nhất 5 lần làm việc với AI | ✓ | 14 lần, có họ tên và MSSV |
| 8 | Giải thích được ít nhất 3 quy tắc CSS trong `style.css` mà không cần mở AI | (tự đánh dấu) | Lời giải thích sẵn trong `GIAI_THICH_3_QUY_TAC_CSS.md`: `display: grid`, `gap`, `@media`. Đánh dấu sau khi bạn tự nói lại được |
| 9 | (Mở rộng) Đã làm ít nhất 2 mục của Bài 3 | ✓ | 3.1, 3.2, 3.3, 3.5, 3.6 trong `BAI_3/BAI3_BAO_CAO.md` |

## Nộp bài

| Việc cần làm | Trạng thái |
| --- | --- |
| 2 ảnh chụp màn hình trang chủ (máy tính và điện thoại) | Đã thay bằng ảnh của bạn: `BAI2_anh-chup-may-tinh.png` (Chrome, `localhost:3000`) và `BAI2_anh-chup-dien-thoai.jpg` (điện thoại thật, `192.168.6.100:3000`) |
| Xoá các thư mục bản sao | ✓ `du-an-web` không còn bản sao, gói nộp đã bỏ `public-thu-nghiem.zip` |
| Nén `du-an-web` thành `.zip` | ✓ `du-an-web.zip` |
| Nộp zip, 2 ảnh và bảng so sánh 1.3 | Sẵn sàng, gói gộp `bai-thuc-hanh-02.zip` |
| Giữ lại thư mục `du-an-web` sau khi nộp | Nhớ không xoá, buổi chiều thêm máy chủ Node.js vào đây |

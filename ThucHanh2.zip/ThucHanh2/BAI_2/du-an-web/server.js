const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Phục vụ các trang tĩnh trong thư mục public
app.use(express.static(path.join(__dirname, 'public')));

// '0.0.0.0' cho phép các thiết bị khác trong mạng truy cập
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Chạy tại http://localhost:${PORT}`);
});
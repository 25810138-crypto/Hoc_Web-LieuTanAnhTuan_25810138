# BẢN ĐẶC TẢ WEBSITE "BÁNH MÂY"

## 1. Tên website và mục đích

- **Tên website:** Bánh Mây
- **Loại website:** bán hàng (giới thiệu tiệm và nhận đặt bánh)
- **Mục đích:** giới thiệu tiệm bánh gia đình, cho khách xem các loại bánh và biết cách đặt bánh. Website chưa có giỏ hàng hay thanh toán; khách đặt qua Zalo hoặc điện thoại.

## 2. Đối tượng người dùng

- Sinh viên quanh khu vực Thủ Đức, cần bánh sinh nhật, bánh cho buổi họp nhóm, bánh ăn nhẹ.
- Nhân viên văn phòng quanh Thủ Đức, cần hộp bánh cho cả phòng hoặc bánh ăn nhẹ buổi chiều.
- Phần lớn xem bằng điện thoại, nên cần chữ dễ đọc, nút bấm to.

## 3. Danh sách trang

| Tên trang | Tên file | Nội dung chính |
| --- | --- | --- |
| Trang chủ | `index.html` | Khối giới thiệu, 4 bánh được chọn nhiều, 3 điểm nổi bật, lời mời đặt bánh |
| Sản phẩm | `san-pham.html` | 8 sản phẩm chia hai nhóm (bánh kem và bánh lạnh, bánh ăn nhẹ), có giá tham khảo |
| Đặt bánh | `dat-banh.html` | 4 bước đặt bánh, thời gian đặt trước, thông tin giao bánh |
| Giới thiệu | `gioi-thieu.html` | Câu chuyện tiệm, địa chỉ, số điện thoại, giờ mở cửa, khu vực giao |

Tổng cộng 4 trang. Tất cả nằm trong `public/` và dùng chung `public/css/style.css`.

## 4. Bố cục chung

- **Đầu trang:** logo chữ "Bánh Mây" kèm dòng "Tiệm bánh nhà làm tại Thủ Đức" bên trái, menu 4 mục bên phải (Trang chủ, Sản phẩm, Đặt bánh, Giới thiệu). Mục của trang đang xem được tô nền nâu.
- **Menu:** giống hệt nhau trên cả 4 trang.
- **Chân trang:** 3 cột (giới thiệu ngắn, giờ mở cửa, liên hệ) và dòng bản quyền.
- **Điểm nhấn:** mép dưới khối giới thiệu và mép trên chân trang lượn như đám mây, gợi tên "Bánh Mây".

## 5. Phong cách

| Vai trò | Màu | Mã màu |
| --- | --- | --- |
| Nền trang | Kem sữa | `#f8f0e3` |
| Nền thẻ, đầu trang | Kem trắng | `#fffbf4` |
| Nền khối nhấn | Cà phê sữa | `#ebdac2` |
| Đường viền | Cát | `#d9c1a1` |
| Chữ chính, chân trang | Nâu ca cao | `#3a2a21` |
| Chữ phụ | Nâu xám | `#6b5547` |
| Nút bấm, giá tiền | Nâu caramel | `#8c5a34` |

- **Phông chữ tiêu đề:** Cambria (dự phòng Georgia, serif).
- **Phông chữ nội dung:** Segoe UI (dự phòng system-ui, Arial, sans-serif).
- Cả hai phông đều có sẵn trên Windows và hỗ trợ tiếng Việt, không cần tải thêm.

## 6. Yêu cầu hiển thị trên điện thoại

- Có thẻ `<meta name="viewport">` trong mọi trang.
- Từ màn hình rộng 760px trở xuống: khối giới thiệu chuyển từ 2 cột thành 1 cột, đầu trang xếp logo trên menu dưới.
- Lưới sản phẩm tự chia 4, 3, 2 hoặc 1 cột tuỳ độ rộng; trên điện thoại là 1 cột.
- Nút bấm trong khối giới thiệu rộng hết hàng trên màn hình nhỏ.
- Không có thanh cuộn ngang ở độ rộng 375px.

## Ngoài phạm vi (để các buổi sau)

Giỏ hàng, thanh toán trực tuyến, đăng nhập, form đặt bánh gửi về máy chủ.

## Thông tin mẫu cần thay trước khi dùng thật

Số điện thoại `0900 000 000`, địa chỉ `12 Đường Số 3, Thủ Đức`, giờ mở cửa, các mức giá và ảnh minh hoạ `placehold.co` đều là dữ liệu mẫu.

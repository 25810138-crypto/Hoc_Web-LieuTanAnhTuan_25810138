# NHẬT KÝ PROMPT

- Họ tên: Liễu Tấn Anh Tuấn
- MSSV: 25810138
- Công cụ AI: Claude

## Lần 1 - Ngày 1, 18:05

- Mục đích: dựng khung dự án và khung ngữ cảnh cho AI.
- Prompt đã dùng: Prompt mẫu 0, điền "bán hàng", "Bánh Mây", "Windows".
- Kết quả: có thư mục du-an-web/public/css và file KHUNG_NGU_CANH.txt.
- Vấn đề gặp phải: không có.
- Điều tôi học được: khung ngữ cảnh cấm React và công cụ build, nên AI không tự đổi công nghệ.

## Lần 2 - Ngày 1, 18:30

- Mục đích: viết bản đặc tả DAC_TA.md.
- Prompt đã dùng: Prompt mẫu 1, nhưng không để AI phỏng vấn. Tôi đưa sẵn thông tin: tiệm bánh gia đình, khách là sinh viên và nhân viên văn phòng quanh Thủ Đức, màu nâu kem nhẹ nhàng, tối đa 4 trang.
- Kết quả: DAC_TA.md đủ 6 mục, 4 trang có tên file viết thường không dấu, có bảng mã màu.
- Vấn đề gặp phải: AI không có số điện thoại, địa chỉ, giờ mở cửa, giá bánh nên phải dùng số liệu mẫu và ghi rõ trong đặc tả.
- Điều tôi học được: thông tin nào AI không biết thì nó chỉ có thể bịa, nên phải ghi rõ đó là dữ liệu mẫu.

## Lần 3 - Ngày 1, 18:55

- Mục đích: phác thảo bố cục trang chủ trước khi viết HTML.
- Prompt đã dùng: Prompt mẫu 2 (vẽ bằng ký tự + - |, hai phiên bản máy tính và điện thoại).
- Kết quả: file BAI2_PHAC_THAO_BO_CUC.md với 5 khu vực: đầu trang, giới thiệu, 4 sản phẩm, điểm nổi bật, chân trang.
- Vấn đề gặp phải: không có.
- Điều tôi học được: phác thảo xong thì biết trước chỗ nào sẽ xếp thành 1 cột trên điện thoại.

## Lần 4 - Ngày 1, 19:20

- Mục đích: dựng trang chủ.
- Prompt đã dùng: Prompt mẫu 3 (HTML5 và CSS3 thuần, 2 file, class tiếng Việt không dấu, ảnh placehold.co).
- Kết quả: public/index.html và public/css/style.css; mở bằng nhấp đúp được, có màu và bố cục theo đặc tả.
- Vấn đề gặp phải: ảnh placehold.co không hiện khi máy không có Internet.
- Điều tôi học được: phải khai báo width và height cho ảnh để bố cục không nhảy khi ảnh tải chậm.

## Lần 5 - Ngày 1, 19:50

- Mục đích: chỉnh lượt 1, sửa chân trang.
- Prompt đã dùng: Prompt mẫu 4, kèm ảnh chụp màn hình trình duyệt giả lập ở độ rộng 1280px.
- Kết quả: chân trang chia 3 cột đều, đường kẻ trên dòng bản quyền chạy hết chiều ngang.
- Vấn đề gặp phải: đường kẻ chỉ dài khoảng nửa chân trang vì thẻ p bị giới hạn max-width: 65ch.
- Điều tôi học được: quy tắc chung của thẻ p ảnh hưởng tới cả chân trang; muốn ngoại lệ phải ghi đè đúng class (.ban-quyen).

## Lần 6 - Ngày 1, 20:10

- Mục đích: chỉnh lượt 2, menu trên điện thoại.
- Prompt đã dùng: Prompt mẫu 4, kèm ảnh chụp ở độ rộng 375px.
- Kết quả: giảm khoảng đệm và cỡ chữ của mục menu ở màn hình dưới 480px.
- Vấn đề gặp phải: mục "Giới thiệu" vẫn xuống hàng thứ hai và lệch trái; xử lý tiếp ở Lần 9.
- Điều tôi học được: kết quả hiển thị phụ thuộc phông chữ của máy, nên phải xem lại trên máy mình.

## Lần 7 - Ngày 1, 20:30

- Mục đích: chỉnh lượt 3, chữ thay thế khi ảnh không tải được.
- Prompt đã dùng: Prompt mẫu 4.
- Kết quả: thuộc tính alt hiện cỡ chữ nhỏ, màu nâu xám, dễ đọc thay vì chữ đen to.
- Vấn đề gặp phải: không có.
- Điều tôi học được: alt vừa giúp người khiếm thị vừa là nội dung hiển thị khi ảnh lỗi.

## Lần 8 - Ngày 1, 20:55

- Mục đích: thêm các trang phụ.
- Prompt đã dùng: Prompt mẫu 5 cho 3 trang: san-pham.html, dat-banh.html, gioi-thieu.html.
- Kết quả: 4 trang dùng chung style.css, cùng đầu trang, menu, chân trang; menu cập nhật ở cả 4 trang, mục trang đang xem có aria-current.
- Vấn đề gặp phải: không có.
- Điều tôi học được: sao chép đầu trang và chân trang vào từng file dễ sai lệch; buổi chiều với EJS sẽ tách ra dùng chung.

## Lần 9 - Ngày 1, 21:30

- Mục đích: kiểm thử, rồi sao lưu public thành public-ban-sao-2.
- Prompt đã dùng: Prompt mẫu 6 (AI đóng vai tester khó tính, đưa toàn bộ nội dung 4 file HTML và style.css), kèm chạy Chrome không giao diện để đo.
- Kết quả: AI liệt kê 6 vấn đề. Tôi tự kiểm tra cả 6, thấy đúng cả. Chọn sửa 2 vấn đề quan trọng nhất: (1) san-pham.html ghi hộp bánh văn phòng nằm nhóm "nhắn trước khoảng 2 giờ" nhưng dat-banh.html ghi phải đặt trước 1 ngày, đã thêm "Đặt trước 1 ngày" vào mô tả và bỏ chữ "Mix cupcake" (không có sản phẩm cupcake); (2) menu trên điện thoại xuống dòng lệch trái, đã căn giữa cả logo và menu. 4 vấn đề còn lại chưa sửa: số điện thoại chưa là liên kết tel:, đầu trang và chân trang chép lặp ở 4 file, ảnh placehold.co phụ thuộc Internet, thông tin liên hệ và giá còn là dữ liệu mẫu.
- Vấn đề gặp phải: AI kiểm thử không đánh giá được màu đẹp xấu, và không tải được ảnh placehold.co khi không có mạng.
- Điều tôi học được: AI tester chỉ ra được cả lỗi nội dung mâu thuẫn giữa hai trang mà mắt thường dễ bỏ sót.

## Lần 10 - Ngày 1, 22:00

- Mục đích: Bài 3.1, tái hiện lỗi mất CSS và báo lỗi bằng dữ kiện.
- Prompt đã dùng: Mẫu báo lỗi (bản rút gọn), điền Console `ERR_FILE_NOT_FOUND` và tên file `styles.css`.
- Kết quả: xác định nguyên nhân là sai tên file trong `<link>`, tự sửa lại thành `css/style.css`.
- Vấn đề gặp phải: dòng lỗi của ảnh placehold.co lẫn vào Console khi không có Internet.
- Điều tôi học được: lọc đúng dòng lỗi liên quan thì báo lỗi ngắn và chính xác hơn.

## Lần 11 - Ngày 1, 22:25

- Mục đích: Bài 3.2, thêm nút "Lên đầu trang" và so sánh đoạn code rời với file đầy đủ.
- Prompt đã dùng: yêu cầu thêm nút, rồi yêu cầu gửi toàn bộ file bị thay đổi.
- Kết quả: nút hoạt động trên bản sao; phải sửa 2 file (`index.html`, `style.css`).
- Vấn đề gặp phải: đoạn code rời không nói rõ dán vào đâu.
- Điều tôi học được: luôn đòi file đầy đủ.

## Lần 12 - Ngày 1, 22:50

- Mục đích: Bài 3.3, kiểm chứng lời giải thích của AI về `display: grid`, `gap`, `@media`.
- Prompt đã dùng: hỏi ý nghĩa 3 dòng CSS và hậu quả khi bỏ từng dòng, sau đó đo lại bằng trình duyệt.
- Kết quả: cả 3 lời giải thích đều đúng với số đo (4 cột so với xếp dọc, khe 24px so với 0px, 2 cột so với 1 cột).
- Vấn đề gặp phải: mốc `max-width: 760px` gồm cả 760px, dễ hiểu nhầm.
- Điều tôi học được: nên tự bật tắt thuộc tính trong DevTools thay vì tin ngay.

## Lần 13 - Ngày 1, 23:20

- Mục đích: Bài 3.5 và 3.6, mở lại cuộc trò chuyện và khôi phục từ bản sao.
- Prompt đã dùng: gói khung ngữ cảnh, đặc tả và các file hiện tại kèm câu kết "Hãy trả lời Đã hiểu".
- Kết quả: có file `BAI3_MO_LAI_CUOC_TRO_CHUYEN.txt`; khôi phục `public` từ `public-ban-sao-2` khớp hoàn toàn bản gốc.
- Vấn đề gặp phải: không có.
- Điều tôi học được: sao lưu `public` trước mỗi lần nhờ AI chỉnh sửa lớn.

## Lần 14 - Ngày 2, 19:06

- Mục đích: chạy trang trên điện thoại thật bằng Node.js.
- Prompt đã dùng: hỏi "chạy Bài 2 trên điện thoại bằng Node.js như thế nào".
- Kết quả: tôi tự viết `server.js` dùng Express phục vụ thư mục `public`, chạy `node server.js`, mở được `localhost:3000` trên máy tính và `192.168.6.100:3000` trên điện thoại cùng Wi-Fi. Menu 4 mục vừa một hàng, khối giới thiệu xếp một cột, tiếng Việt hiển thị đúng.
- Vấn đề gặp phải: Console báo lỗi 404 cho `/favicon.ico` vì trang chưa có biểu tượng; không ảnh hưởng hoạt động của trang.
- Điều tôi học được: điện thoại phải dùng địa chỉ IP của máy tính chứ không dùng `localhost`, và máy chủ phải lắng nghe ở `0.0.0.0`.

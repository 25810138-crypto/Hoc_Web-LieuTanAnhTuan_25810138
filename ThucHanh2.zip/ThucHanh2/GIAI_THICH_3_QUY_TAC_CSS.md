# Tiêu chí 8: giải thích 3 quy tắc CSS trong style.css

## 1. `display: grid;` (trong `.luoi-san-pham`)

- **Làm gì:** biến khung chứa thành một lưới, nên các thẻ sản phẩm được xếp thành hàng và cột.
- **Nếu bỏ:** 4 thẻ xếp dọc từng cái một. Đo được: độ cao của các thẻ là 459, 1383, 2306 và 3229px thay vì cùng một hàng 459px.

## 2. `gap: 24px;`

- **Làm gì:** tạo khoảng cách 24px giữa các ô của lưới, cả chiều ngang lẫn chiều dọc.
- **Nếu bỏ:** khoảng cách giữa hai thẻ về 0px, các thẻ dính sát nhau.

## 3. `@media (max-width: 760px) { ... }`

- **Làm gì:** các quy tắc bên trong chỉ có hiệu lực khi màn hình rộng từ 760px trở xuống (điện thoại, máy tính bảng nhỏ). Ở trang chủ, nó đổi khối giới thiệu từ 2 cột thành 1 cột, ảnh xuống dưới chữ.
- **Nếu bỏ:** trên điện thoại hai cột bị ép nhỏ và chật.
- **Lưu ý:** mốc 760px tính cả 760px. Ở 761px vẫn là 2 cột, ở 760px đã là 1 cột.

## Cách kiểm chứng

Mở trang bằng Chrome, bấm **Ctrl + Shift + C**, chọn phần tử, rồi bỏ dấu tích trước thuộc tính trong khung **Styles** để xem trang thay đổi.
